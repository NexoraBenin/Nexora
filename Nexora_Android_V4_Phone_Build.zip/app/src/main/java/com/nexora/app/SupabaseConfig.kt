package com.nexora.app

object SupabaseConfig {
    const val URL = "https://nerodzrdafzsbnmbafhq.supabase.co"
    const val PUBLISHABLE_KEY = "sb_publishable_SFuejuyohjDI7SLwgj6EPA_GS4M5JW2"
}
