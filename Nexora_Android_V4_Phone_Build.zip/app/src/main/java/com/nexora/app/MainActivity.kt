package com.nexora.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Anonymous

private val Navy = Color(0xFF071522)
private val Panel = Color(0xFF0D2133)
private val Blue = Color(0xFF2D8CFF)
private val TextMain = Color(0xFFEAF3FF)
private val Muted = Color(0xFF8FA6BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexoraApp() }
    }
}

@Composable
fun NexoraApp() {
    var connected by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        try {
            if (NexoraBackend.client.auth.currentUserOrNull() == null) {
                NexoraBackend.client.auth.signInAnonymously()
            }
            connected = true
        } catch (_: Exception) {
            connected = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = TextMain, onSurface = TextMain
    )) {
        if (connected) {
            ChatHome()
        } else {
            ConnectionScreen { 
                try {
                    // Re-run by recreating state through a simple sign-in attempt.
                    kotlinx.coroutines.GlobalScope.launch {
                        NexoraBackend.client.auth.signInAnonymously()
                    }
                } catch (_: Exception) {}
            }
        }
    }
}

@Composable
fun ConnectionScreen(onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Navy), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(30.dp)) {
            Box(Modifier.size(80.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Send, null, tint = Color.White, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("Nexora", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Connexion au serveur impossible.", color = Muted)
            Spacer(Modifier.height(18.dp))
            Button(onClick = onRetry) { Text("Réessayer") }
        }
    }
}

data class DemoChat(val name: String, val preview: String, val time: String, val unread: Int)

val demoChats = listOf(
    DemoChat("Léa", "À demain alors ! 😊", "14:32", 2),
    DemoChat("Groupe des amis", "Thomas : C'est parti pour ce soir ?", "14:21", 5),
    DemoChat("Mathis", "T'as vu la vidéo ? 😄", "13:17", 1),
    DemoChat("Voyages & Aventures", "Sophie : Incroyable ce pays !", "12:48", 3),
    DemoChat("Emma", "Merci beaucoup !", "11:02", 0)
)

@Composable
fun ChatHome() {
    var selected by remember { mutableStateOf<DemoChat?>(null) }
    if (selected == null) {
        Column(Modifier.fillMaxSize().background(Navy)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Send, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Nexora", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Discutez. Partagez. Connectez-vous.", color = Muted, fontSize = 12.sp)
                }
                IconButton(onClick = {}) { Icon(Icons.Default.Settings, null) }
            }
            OutlinedTextField(
                value = "", onValueChange = {}, readOnly = true,
                placeholder = { Text("Rechercher...", color = Muted) },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                shape = RoundedCornerShape(18.dp)
            )
            Text("Discussions", Modifier.padding(18.dp), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            LazyColumn {
                items(demoChats) { chat ->
                    Row(
                        Modifier.fillMaxWidth().clickable { selected = chat }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(52.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) {
                            Text(chat.name.take(1), fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(chat.name, fontWeight = FontWeight.SemiBold)
                            Text(chat.preview, color = Muted, maxLines = 1)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(chat.time, color = Muted, fontSize = 11.sp)
                            if (chat.unread > 0) {
                                Spacer(Modifier.height(4.dp))
                                Box(Modifier.size(22.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) {
                                    Text(chat.unread.toString(), fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        LiveChat(chat = selected!!, onBack = { selected = null })
    }
}

@Composable
fun LiveChat(chat: DemoChat, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var recorder: MediaRecorder? by remember { mutableStateOf(null) }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) recording = true
    }

    DisposableEffect(Unit) {
        onDispose { recorder?.release() }
    }

    Scaffold(
        containerColor = Navy,
        topBar = {
            Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                Box(Modifier.size(42.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) {
                    Text(chat.name.take(1), fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(chat.name, fontWeight = FontWeight.Bold)
                    Text("● en ligne", color = Color(0xFF35D07F), fontSize = 12.sp)
                }
                IconButton(onClick = {}) { Icon(Icons.Default.Call, null) }
                IconButton(onClick = {}) { Icon(Icons.Default.Videocam, null) }
            }
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {}) { Icon(Icons.Default.AttachFile, null) }
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    placeholder = { Text("Écrire un message...", color = Muted) },
                    modifier = Modifier.weight(1f), singleLine = true,
                    shape = RoundedCornerShape(22.dp)
                )
                if (text.isNotBlank()) {
                    IconButton(onClick = { text = "" }) {
                        Icon(Icons.Default.Send, null, tint = Blue)
                    }
                } else {
                    IconButton(onClick = {
                        val granted = ContextCompat.checkSelfPermission(
                            androidx.compose.ui.platform.LocalContext.current,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) recording = !recording
                        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }) {
                        Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = Blue)
                    }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Surface(color = Color(0xFF193249), shape = RoundedCornerShape(18.dp)) {
                    Text("Salut ! 👋\nTu vas bien aujourd'hui ?", Modifier.padding(15.dp))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Surface(color = Blue, shape = RoundedCornerShape(18.dp)) {
                        Text("Oui ça va super ! Et toi ?", Modifier.padding(15.dp))
                    }
                }
            }
            item {
                Surface(color = Color(0xFF193249), shape = RoundedCornerShape(18.dp)) {
                    Text("Bien aussi ! Je termine juste un truc et après je suis libre 😊", Modifier.padding(15.dp))
                }
            }
            if (recording) {
                item {
                    Text("🎙️ Enregistrement vocal en cours…", color = Blue, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
