# Configuration Supabase

## 1. Projet
Créer un projet sur Supabase.

## 2. Authentification sans téléphone
Authentication > Providers > Anonymous Sign-Ins : activer.

Supabase permet ainsi une authentification sans e-mail, mot de passe ou numéro.
Attention : un compte anonyme n'est pas récupérable sur un autre appareil tant qu'on
n'a pas lié un moyen de connexion.

## 3. Base de données
Copier `schema.sql` dans le SQL Editor puis exécuter.

## 4. Realtime
La table `messages` est ajoutée à `supabase_realtime` par le script.

## 5. Application
Copier l'URL du projet et la clé publishable dans :
`app/src/main/java/com/nexora/app/SupabaseConfig.kt`

Ne jamais mettre une `service_role` key dans l'application Android.
