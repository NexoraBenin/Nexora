# Nexora V2 — messagerie Android temps réel

Cette version prépare Nexora pour de vrais utilisateurs avec Supabase :
- comptes anonymes (aucun numéro ni e-mail obligatoire)
- profils avec pseudo
- messages texte en temps réel
- groupes/conversations extensibles
- stockage des fichiers et vocaux
- bouton d'enregistrement vocal (base Android)
- architecture prête pour notifications et appels

## Gratuit pour démarrer
Supabase propose actuellement une offre Free avec base PostgreSQL 500 MB, 1 GB de stockage,
2 millions de messages Realtime/mois et 200 connexions simultanées. Les projets gratuits
peuvent être mis en pause après une période d'inactivité. Vérifie les quotas avant une
mise en production à grande échelle.

## Mise en route
1. Crée un projet Supabase.
2. Active Authentication > Anonymous Sign-Ins.
3. Dans SQL Editor, exécute `supabase/schema.sql`.
4. Récupère l'URL du projet et la clé publishable.
5. Mets-les dans `app/src/main/java/com/nexora/app/SupabaseConfig.kt`.
6. Ouvre le dossier dans Android Studio et synchronise Gradle.
7. Build > Build APK(s).

## Limite volontaire
L'authentification anonyme ne demande aucune donnée personnelle, mais elle est liée à
l'installation/appareil. La récupération/transfert d'un compte vers un autre téléphone
sera ajoutée ensuite avec un mécanisme de récupération sécurisé.

Les appels audio/vidéo nécessitent WebRTC + signalisation. Ils sont prévus dans
l'architecture mais ne sont pas présentés comme déjà fonctionnels dans cette V2.
